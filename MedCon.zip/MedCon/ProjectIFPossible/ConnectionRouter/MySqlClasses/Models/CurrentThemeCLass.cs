﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectIFPossible.ConnectionRouter.MySqlClasses.Models
{
    class CurrentThemeCLass
    {
        public static Theme currentTheme = Themes.Green;
    }
}
