﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectIFPossible
{
  public class SettingSet
    {
        public SettingCollection st {get; set;}
        public UserCreadential usc { get; set; }
    }
}
